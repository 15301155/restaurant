package com.cn.hnust.servic;

import com.cn.hnust.been.Person;
import com.cn.hnust.been.Search;;

public interface ISearchService {

	public String Search(String search);
	
}
