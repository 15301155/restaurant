package com.cn.hnust.servic;

import com.cn.hnust.been.User;


	 public interface IUserService {  
		    public User getUserById(int userId);  
}
