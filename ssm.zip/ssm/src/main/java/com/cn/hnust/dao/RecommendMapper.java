package com.cn.hnust.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.cn.hnust.been.Recommend;
import com.cn.hnust.been.Search;

public class RecommendMapper {
	Recommend selectbyname(String search);
}
